from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from .models import MenuItem
from django.contrib.auth.models import User

class MenuItemAPITest(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.menu_item = MenuItem.objects.create(title='Burger', price=9.99, inventory=5)
        self.client.force_authenticate(user=self.user)

    def test_get_menu_items(self):
        response = self.client.get('/api/menu/items/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)

    def test_create_menu_item(self):
        data = {"title": "Pizza", "price": 12.99, "inventory": 10}
        response = self.client.post('/api/menu/items/', data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(MenuItem.objects.count(), 2)
