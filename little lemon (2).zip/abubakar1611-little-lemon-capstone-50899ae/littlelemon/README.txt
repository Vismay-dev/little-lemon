Capstone Project - Little Lemon API  
Name: Ali Ahmad  
Django Version: 5.2.3  
MySQL Version: 8.x  

API paths to test:  
/api/menu/  
/api/bookings/  
/api/token/  
/api/token/refresh/  

Setup Instructions:  
1. Clone the repo  
2. pip install -r requirements.txt  
3. Update DB settings in settings.py  
4. py manage.py migrate  
5. py manage.py createsuperuser  
6. py manage.py runserver  
